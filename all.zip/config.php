<?php
return [
    'EmailTo' => 'bookings@corporatebusinessclass.com',
    'EmailFrom' => 'bookings@corporatebusinessclass.com',
    'Password' => 'Travel1234@',
];
?>